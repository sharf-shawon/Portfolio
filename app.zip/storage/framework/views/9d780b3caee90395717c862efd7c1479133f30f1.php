<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>

    <title><?php echo e($data->title ?? setting("site.title")); ?></title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="title" content="<?php echo e($data->title ?? setting('site.title')); ?>">
    <meta name="keywords" content="<?php echo e($data->metatags ?? setting('site.metatags')); ?>">
    <meta name="description" content="<?php echo e($data->metadescription ?? setting('site.description')); ?>">
    <meta property="og:title" content="<?php echo e($data->title ?? setting('site.title')); ?>">
    <meta property="og:description" content="<?php echo e($data->metadescription ?? setting('site.description')); ?>">
    <meta property="og:image" content="<?php echo e(Voyager::image($data->image ?? setting("site.shareImage"))); ?>">
    <meta property="og:url" content="<?php echo e(Request::url()); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta property="og:site_name" content="<?php echo e(setting('site.name')); ?>">
    <meta name="twitter:image:alt" content="<?php echo e(setting('site.description')); ?>">
    <meta property="fb:app_id" content="<?php echo e(config('services.facebook.client_id')); ?>" />
    <meta name="twitter:site" content="<?php echo e(setting('site.twitter')); ?>">
    <meta name="theme-color" content="#2B2B35">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo e(asset("favicons/ms-icon-144x144.png")); ?>">
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset("favicons/apple-icon-57x57.png")); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset("favicons/apple-icon-60x60.png")); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset("favicons/apple-icon-72x72.png")); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset("favicons/apple-icon-76x76.png")); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset("favicons/apple-icon-114x114.png")); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset("favicons/apple-icon-120x120.png")); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset("favicons/apple-icon-144x144.png")); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset("favicons/apple-icon-152x152.png")); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset("favicons/apple-icon-180x180.png")); ?>">
    <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(asset("favicons/android-icon-192x192.png")); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset("favicons/favicon-32x32.png")); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset("favicons/favicon-96x96.png")); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset("favicons/favicon-16x16.png")); ?>">
    <link rel="manifest" href="<?php echo e(asset("favicons/manifest.json")); ?>">

    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

    <!-- Load Facebook SDK for JavaScript -->
    <div id="fb-root"></div>
    <script>
        window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v8.0'
        });
      };

      (function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
    </script>

    <!-- Your Chat Plugin code -->
    <div class="fb-customerchat" attribution=setup_tool page_id="109067674101893" theme_color="#FFC107"
        logged_in_greeting="Hello! Welcome to my website!" logged_out_greeting="Hello! Welcome to my website!">
    </div>
    <!-- app -->
    <div class="art-app">

        <!-- mobile top bar -->
        <div class="art-mobile-top-bar"></div>

        <!-- app wrapper -->
        <div class="art-app-wrapper">

            <!-- app container end -->
            <div class="art-app-container">
                <?php echo $__env->make('inc.public.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- content -->
                <div class="art-content">

                    <!-- curtain -->
                    <div class="art-curtain"></div>

                    <!-- top background -->
                    <div class="art-top-bg" style="background-image: url(img/bg.gif)">
                        <!-- overlay -->
                        <div class="art-top-bg-overlay"></div>
                        <!-- overlay end -->
                    </div>
                    <!-- top background end -->

                    <!-- swup container -->
                    <div class="transition-fade" id="swup">

                        <!-- scroll frame -->
                        <div id="scrollbar" class="art-scroll-frame">
                            <?php echo $__env->yieldContent('content'); ?>
                            <!-- container -->
                            <div class="container-fluid">

                                <!-- footer -->
                                <footer>
                                    <!-- copyright -->
                                    <div>© <?php echo e(date("Y")); ?> <?php echo e(setting("site.name")); ?></div>
                                    <div>All Rights Reserved.</div>
                                </footer>
                                <!-- footer end -->

                            </div>
                            <!-- container end -->

                        </div>
                        <!-- scroll frame end -->

                    </div>
                    <!-- swup container end -->

                </div>
                <!-- content end -->
                <?php echo $__env->make('inc.public.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- app container end -->

        </div>
        <!-- app wrapper end -->

        <!-- preloader -->
        <div class="art-preloader">
            <!-- preloader content -->
            <div class="art-preloader-content">
                <!-- title -->
                <h4><?php echo e(setting("site.name")); ?></h4>
                <!-- progressbar -->
                <div id="preloader" class="art-preloader-load"></div>
            </div>
            <!-- preloader content end -->
        </div>
        <!-- preloader end -->

    </div>
    <!-- app end -->    <script src="<?php echo e(asset("js/main.js")); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH H:\Projects\portfolio\resources\views/layouts/public.blade.php ENDPATH**/ ?>