<!-- menu bar -->
<div class="art-menu-bar">

    <!-- menu bar frame -->
    <div class="art-menu-bar-frame">

        <!-- menu bar header -->
        <div class="art-menu-bar-header">
            <!-- menu bar button -->
            <a class="art-menu-bar-btn" href="#.">
                <!-- icon -->
                <span></span>
            </a>
            <!-- menu bar button end -->
        </div>
        <!-- menu bar header end -->

        <!-- current page title -->
        <div class="art-current-page"></div>
        <!-- current page title end -->

        <!-- scroll frame -->
        <div class="art-scroll-frame">

            <!-- menu -->
            <nav id="swupMenu">
                <!-- menu list -->
                <ul class="main-menu">
                    <!-- menu item -->
                    <li class="menu-item <?php echo e(isActive("")); ?>"><a href="<?php echo e(url("/")); ?>">Home</a></li>
                    <!-- menu item -->
                    <li class="menu-item <?php echo e(isActive("career")); ?>"><a href="<?php echo e(url("career")); ?>">Career</a></li>
                    <!-- menu item -->
                    <li class="menu-item <?php echo e(isActive("contact")); ?>"><a href="<?php echo e(url("contact")); ?>">Contact</a></li>
                    <!-- menu item -->
                    <li class="menu-item <?php echo e(isActive("portfolio")); ?>"><a href="<?php echo e(url("portfolio")); ?>">Portfolio</a></li>
                    <!-- menu item -->
                    <li class="menu-item <?php echo e(isActive("blog")); ?>"><a href="<?php echo e(url("blog")); ?>">Blog</a></li>
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="menu-item <?php echo e(isActive("signin")); ?>"><a href="<?php echo e(url("signin")); ?>">Sign In</a></li>
                    <?php endif; ?>
                    <!-- menu item -->
                    <!-- menu item -->
                    <?php if(Auth::check() && Auth::user()->hasRole('admin')): ?>
                    <li class="menu-item"><a href="<?php echo e(url("backend")); ?>" target="">Backend</a></li>
                    <?php endif; ?>
                    <!-- menu item -->
                    <li class="menu-item <?php echo e(isActive("privacy-policy")); ?>"><a href="<?php echo e(url("privacy-policy")); ?>">Privacy Policy</a></li>
                </ul>
                <!-- menu list end -->
            </nav>
            <!-- menu end -->

            <!-- language change -->
            <ul class="art-language-change">
                <!-- language item -->
                <?php if(auth()->guard()->check()): ?>
                <li>
                    <a><?php echo e(Auth::user()->name); ?></a>
                </li>
                <li>
                    <a href="#"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                </li>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                <?php else: ?>
                <li class="art-active-lang"><a href="/signin">Sign In</a></li>
                <?php endif; ?>
                <!-- language item -->
            </ul>
            <!-- language change end -->

        </div>
        <!-- scroll frame end -->

    </div>
    <!-- menu bar frame -->

</div>
<!-- menu bar end -->
<?php /**PATH H:\Projects\portfolio\resources\views/inc/public/menu.blade.php ENDPATH**/ ?>