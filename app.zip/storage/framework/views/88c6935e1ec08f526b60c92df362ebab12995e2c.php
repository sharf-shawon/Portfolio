<?php $__env->startSection('content'); ?>


<!-- container -->
<div class="container-fluid">

    <!-- row -->
    <div class="row p-30-0">

        <!-- col -->
        <div class="col-lg-12">

            <!-- section title -->
            <div class="art-section-title">
                <!-- title frame -->
                <div class="art-title-frame">
                    <!-- title -->
                    <h4>Blog</h4>
                </div>
                <!-- title frame end -->
            </div>
            <!-- section title end -->

        </div>
        <!-- col end -->
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!-- col -->
        <div class="col-lg-6">

            <!-- blog post card -->
            <div class="art-a art-blog-card">
                <!-- post cover -->
                <a href="<?php echo e(url("blog/{$item->id}/".Str::slug($item->title))); ?>" class="art-port-cover">
                    <!-- img -->
                    <img src="<?php echo e(Voyager::image($item->image)); ?>" alt="blog post">
                </a>
                <!-- post cover end -->
                <!-- post description -->
                <div class="art-post-description">
                    <!-- title -->
                    <a href="<?php echo e(url("blog/{$item->id}/".Str::slug($item->title))); ?>">
                        <h5 class="mb-15"><?php echo e($item->title); ?></h5>
                    </a>
                    <!-- text -->
                    <div class="mb-15"><?php echo $item->excerpt; ?></div>
                    <!-- link -->
                    <a href="<?php echo e(url("blog/{$item->id}/".Str::slug($item->title))); ?>"
                        class="art-link art-color-link art-w-chevron">Read more</a>
                </div>
                <!-- post description end -->
            </div>
            <!-- blog post card end -->

        </div>
        <!-- col end -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <!-- row end -->

</div>
<!-- container end -->

<?php echo e($data->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Projects\portfolio\resources\views/blog.blade.php ENDPATH**/ ?>