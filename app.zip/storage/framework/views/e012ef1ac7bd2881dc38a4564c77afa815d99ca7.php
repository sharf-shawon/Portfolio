<!-- info bar -->
<div class="art-info-bar">

    <!-- menu bar frame -->
    <div class="art-info-bar-frame">

        <!-- info bar header -->
        <div class="art-info-bar-header">
            <!-- info bar button -->
            <a class="art-info-bar-btn" href="#.">
                <!-- icon -->
                <i class="fas fa-ellipsis-v"></i>
            </a>
            <!-- info bar button end -->
        </div>
        <!-- info bar header end -->

        <!-- info bar header -->
        <div class="art-header">
            <!-- avatar -->
            <div class="art-avatar">
                <a data-fancybox="avatar" href="https://graph.facebook.com/100007290403062/picture?type=large"
                    class="art-avatar-curtain">
                    <img src="https://graph.facebook.com/100007290403062/picture?type=large" alt="avatar">
                    <i class="fas fa-expand"></i>
                </a>
                <!-- available -->
                <div class="art-lamp-light">
                    <!-- add class 'art-not-available' if not available-->
                    <div class="art-available-lamp"></div>
                </div>
            </div>
            <!-- avatar end -->
            <!-- name -->
            <h5 class="art-name mb-10"><a href="<?php echo e(url("/")); ?>"><?php echo e(setting("site.name")); ?></a></h5>
            <!-- post -->
            <div class="art-sm-text"><?php echo e(setting("site.designation")); ?></div>
        </div>
        <!-- info bar header end -->

        <!-- scroll frame -->
        <div id="scrollbar2" class="art-scroll-frame">

            <!-- info bar about -->
            <div class="art-table p-15-15">
                <!-- about text -->
                <ul>
                    <!-- country -->
                    <li>
                        <h6>Residence:</h6><span><?php echo e(setting("site.country")); ?></span>
                    </li>
                    <!-- city -->
                    <li>
                        <h6>City:</h6><span><?php echo e(setting("site.city")); ?></span>
                    </li>
                    <!-- age -->
                    <li>
                        <h6>Age:</h6><span><?php echo e(setting("site.age")); ?></span>
                    </li>
                </ul>
            </div>
            <!-- info bar about end -->

            <!-- divider -->
            <div class="art-ls-divider"></div>

            <!-- links frame -->
            <div class="art-links-frame p-15-15">

                <!-- download cv button -->
                <a href="<?php echo e(hideConf('#')); ?>" id="cvb" class="art-link art-color-link text-center">Download CV <i
                        class="fas fa-download"></i></a>
            </div>
            <!-- links frame end -->

            <!-- divider -->
            <div class="art-ls-divider"></div>

            <!-- language skills -->
            <div class="art-lang-skills p-30-15">
                <?php $__currentLoopData = explode("|", setting('site.languages')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $item = explode(",", $item); ?>
                <div class="art-lang-skills-item">
                    <div id="circleprog<?php echo e($key); ?>" class="art-cirkle-progress circleprog" val="<?php echo e($item[1]); ?>"></div>
                    <!-- title -->
                    <h6><?php echo e($item[0]); ?></h6>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- language skills end -->

            <!-- divider -->
            <div class="art-ls-divider"></div>

            <!-- Programming Languages -->
            <div class="art-hard-skills p-30-15">

                <?php $__currentLoopData = explode("|", setting('site.programmingLanguages')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $item = explode(",", $item); ?>
                <div class="art-hard-skills-item">
                    <div class="art-skill-heading">
                        <!-- title -->
                        <h6><?php echo e($item[0]); ?></h6>
                    </div>
                    <!-- progressbar frame -->
                    <div class="art-line-progress">
                        <!-- progressbar -->
                        <div id="lineprog<?php echo e($key); ?>" val="<?php echo e($item[1]); ?>" class="lineprog"></div>
                    </div>
                    <!-- progressbar frame end -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <!-- Programming languages end -->

            <!-- divider -->
            <div class="art-ls-divider"></div>

            <!-- knowledge list -->
            <ul class="art-knowledge-list p-15-0">
                <?php $__currentLoopData = explode("|", setting("site.skills")); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- list item -->
                <li><?php echo e($item); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <!-- knowledge list end -->

        </div>
        <!-- scroll frame end -->

        <!-- sidebar social -->
        <div class="art-ls-social">
            <!-- social link -->
            <a href="<?php echo e(hideConf(setting("site.facebook"))); ?>" target="_blank"><i class="fab fa-facebook"></i></a>
            <!-- social link -->
            <a href="<?php echo e(hideConf(setting("site.linkedin"))); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a>
            <!-- social link -->
            <a href="<?php echo e(hideConf(setting("site.github"))); ?>" target="_blank"><i class="fab fa-github"></i></a>
            <!-- social link -->
            <a href="<?php echo e(hideConf(setting("site.twitter"))); ?>" target="_blank"><i class="fab fa-twitter"></i></a>
            <!-- social link -->
            <a href="<?php echo e(hideConf(setting("site.youtube"))); ?>" target="_blank"><i class="fab fa-youtube"></i></a>
        </div>
        <!-- sidebar social end -->

    </div>
    <!-- menu bar frame end -->

</div>
<!-- info bar end -->
<?php if(Auth::check()): ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $("#cvb").on("click", function(){ location.href = '/cv'; })
    $(document).ready(function(){


    });
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\portfolio\resources\views/inc/public/sidebar.blade.php ENDPATH**/ ?>