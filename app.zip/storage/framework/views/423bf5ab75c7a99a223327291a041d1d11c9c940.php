<?php $__env->startSection('content'); ?>

<!-- container -->
<div class="container-fluid">

    <!-- row -->
    <div class="row p-60-0 p-lg-30-0 p-md-15-0">
        <!-- col -->
        <div class="col-lg-12">

            <!-- banner -->
            <div class="art-a art-banner" style="background-image: url(img/bg.gif)">
                <!-- banner back -->
                <div class="art-banner-back"></div>
                <!-- banner dec -->
                <div class="art-banner-dec"></div>
                <!-- banner overlay -->
                <div class="art-banner-overlay">
                    <!-- main title -->
                    <div class="art-banner-title">
                        <!-- title -->
                        <h1 class="mb-15"><?php echo e(setting("site.headerText")); ?></h1>
                        <!-- suptitle -->
                        <div class="art-lg-text art-code mb-25">&lt;<i>code</i>&gt; I Love
                            <span class="txt-rotate" data-period="2000"
                                data-rotate='<?php echo e(setting('site.moving')); ?>'></span>&lt;/<i>code</i>&gt;
                        </div>
                        <div class="art-buttons-frame">
                            <!-- button -->
                            <a href="<?php echo e(hideConf(setting("site.ctaLink"))); ?>"
                                class="art-btn art-btn-md"><span><?php echo e(setting("site.ctaText")); ?></span></a>
                        </div>
                    </div>
                    <!-- main title end -->
                    <!-- photo -->
                    <img src="<?php echo e(Voyager::image(setting("site.headerImage"))); ?>" class="art-banner-photo"
                        alt="<?php echo e(setting("site.name")); ?>">
                </div>
                <!-- banner overlay end -->
            </div>
            <!-- banner end -->

        </div>
        <!-- col end -->
    </div>
    <!-- row end -->

</div>
<!-- container end -->

<!-- container -->
<div class="container-fluid">
    <!-- row -->
    <div class="row p-30-0">
        <div class="col-md-12">
            <div class="art-a art-service-icon-box">
                <!-- service content -->
                <div class="art-service-ib-content">
                    <!-- title -->
                    <h5 class="mb-15">About Me</h5>
                    <!-- text -->
                    <div class="mb-15 text-white">
                        <?php echo setting('site.about'); ?>

                    </div>
                    <!-- button -->
                </div>
                <!-- service content end -->
            </div>

        </div>
    </div>
</div>
<!-- container end -->

<div class="container-fluid text-center">

    <!-- row -->
    <div class="row p-20-0">

        <!-- col -->
        <div class="col-md-3 col-6">

            <!-- couner frame -->
            <div class="art-counter-frame">
                <!-- counter -->
                <div class="art-counter-box">
                    <!-- counter number -->
                    <span class="art-counter"><?php echo e(setting("site.experience")); ?></span><span
                        class="art-counter-plus">+</span>
                </div>
                <!-- counter end -->
                <!-- title -->
                <h6>Years Experience</h6>
            </div>
            <!-- couner frame end -->

        </div>
        <!-- col end -->

        <!-- col -->
        <div class="col-md-3 col-6">

            <!-- couner frame -->
            <div class="art-counter-frame">
                <!-- counter -->
                <div class="art-counter-box">
                    <!-- counter number -->
                    <span class="art-counter"><?php echo e(setting("site.projects")); ?></span>
                </div>
                <!-- counter end -->
                <!-- title -->
                <h6>Completed Projects</h6>
            </div>
            <!-- couner frame end -->

        </div>
        <!-- col end -->

        <!-- col -->
        <div class="col-md-3 col-6">

            <!-- couner frame -->
            <div class="art-counter-frame">
                <!-- counter -->
                <div class="art-counter-box">
                    <!-- counter number -->
                    <span class="art-counter"><?php echo e(setting("site.clients")); ?></span>
                </div>
                <!-- counter end -->
                <!-- title -->
                <h6>Happy Clients</h6>
            </div>
            <!-- couner frame end -->

        </div>
        <!-- col end -->

        <!-- col -->
        <div class="col-md-3 col-6">

            <!-- couner frame -->
            <div class="art-counter-frame">
                <!-- counter -->
                <div class="art-counter-box">
                    <!-- counter number -->
                    <span class="art-counter"><?php echo e(setting("site.achievements")); ?></span><span
                        class="art-counter-plus">+</span>
                </div>
                <!-- counter end -->
                <!-- title -->
                <h6>Achievements</h6>
            </div>
            <!-- couner frame end -->

        </div>
        <!-- col end -->

    </div>
    <!-- row end -->

</div>
<!-- container end -->
<?php echo $__env->make('inc.public.hobbies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('inc.public.recommendations', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('inc.public.brands', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Projects\portfolio\resources\views/index.blade.php ENDPATH**/ ?>