<?php if(App\Hobby::where('active', true)->count() > 0): ?>
<!-- container -->
<div class="container-fluid">

    <!-- row -->
    <div class="row">

        <!-- col -->
        <div class="col-lg-12">

            <!-- section title -->
            <div class="art-section-title">
                <!-- title frame -->
                <div class="art-title-frame">
                    <!-- title -->
                    <h4>My Hobbies</h4>
                </div>
                <!-- title frame end -->
            </div>
            <!-- section title end -->

        </div>
        <!-- col end -->
        <?php $__currentLoopData = App\Hobby::where('active', true)->inRandomOrder()->limit(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!-- col -->
        <div class="col-lg-4 col-md-6">

            <!-- service -->
            <div class="art-a art-service-icon-box">
                <!-- service content -->
                <div class="art-service-ib-content">
                    <!-- title -->
                    <h5 class="mb-15"><?php echo e($item->title); ?></h5>
                    <!-- text -->
                    <div class="mb-15"><?php echo $item->description; ?></div>
                </div>
                <!-- service content end -->
            </div>
            <!-- service end -->

        </div>
        <!-- col end -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <!-- row end -->

</div>
<!-- container end -->
<?php endif; ?>


<?php /**PATH H:\Projects\portfolio\resources\views/inc/public/hobbies.blade.php ENDPATH**/ ?>