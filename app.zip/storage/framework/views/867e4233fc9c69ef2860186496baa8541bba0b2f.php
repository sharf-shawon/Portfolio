<?php if($paginator->hasPages()): ?>
<!-- container -->
<div class="container-fluid">

    <!-- row -->
    <div class="row pb-3">

        <!-- col -->
        <div class="col-lg-12">

            <!-- pagination -->
            <div class="art-a art-pagination">
                <!-- button -->
                <?php if($paginator->onFirstPage()): ?>
                <a href="#" class="art-link art-color-link art-w-chevron art-left-link disabled"><span>Previous
                        page</span></a>
                <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>"
                    class="art-link art-color-link art-w-chevron art-left-link"><span>Previous page</span></a>
                <?php endif; ?>
                <div class="art-pagination-center art-m-hidden">

                
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                <a class="disabled" href="#"><?php echo e($element); ?></a>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                <a class="art-active-pag" href="#"><?php echo e($page); ?></a>
                <?php else: ?>
                <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="art-link art-color-link art-w-chevron"><span>Next page</span></a>
                <?php else: ?>
                <a href="#" class="art-link art-color-link art-w-chevron disabled"><span>Next page</span></a>
                <?php endif; ?>
                <!-- button -->
            </div>
            <!-- pagination end -->

        </div>
        <!-- col end -->

    </div>
    <!-- row end -->

</div>
<!-- container end -->

<?php endif; ?>
<?php /**PATH H:\Projects\portfolio\resources\views/vendor/pagination/default.blade.php ENDPATH**/ ?>