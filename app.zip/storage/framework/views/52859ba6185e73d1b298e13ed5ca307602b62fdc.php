<?php if(App\Framework::where('active', true)->count()): ?>
<!-- container -->
<div class="container-fluid">

    <!-- col -->
    <div class="col-lg-12">

        <!-- section title -->
        <div class="art-section-title">
            <!-- title frame -->
            <div class="art-title-frame">
                <!-- title -->
                <h4>Frameworks I am best at</h4>
            </div>
            <!-- title frame end -->
        </div>
        <!-- section title end -->

    </div>
    <!-- col end -->

    <!-- row -->
    <div class="row">

        <?php $__currentLoopData = App\Framework::where('active', true)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4 col-lg-2">
            <!-- brand -->
            <img class="art-brand" src="<?php echo e(Voyager::image($item->image)); ?>" alt="<?php echo e($item->name); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- col end -->

    </div>
    <!-- row end -->

</div>
<!-- container end -->
<?php endif; ?>
<?php /**PATH H:\Projects\portfolio\resources\views/inc/public/brands.blade.php ENDPATH**/ ?>